<!DOCTYPE html>
<html lang="en">
   

   <?php
            
       $carrotqty = $_POST['carrotqty'];
       $bellpepperqty = $_POST['bellpepperqty'];
       $tomatoqty = $_POST['tomatoqty'];
       $totalqty = 0;
       $totalamount = 0.00;
?>
    <head>
        <meta charset="utf-8">
        <title>Sunflower Farms- Order Complete</title>
        <link rel="shortcut icon" href="images/favicon.ico">
        <link rel="stylesheet" href="styles/normalize.css">
        <link rel="stylesheet" href="styles/main.css">
    </head>
   
    <body>
       <header>
           <img src="images/logo.png" alt="Sunflower Farms Logo" height="80">
           <h2>Sunflower Farms</h2>
       </header>
   <main>
       <section>
        <h1>Sunflower Farms</h1>
        <h2>Order Confirmed</h2>
        
    <?php
        
        echo ' Thanks, ';
        echo $_POST['firstname'] . ' ' . $_POST['lastname'];
        echo ' you ordered: </br>';
        echo htmlspecialchars($carrotqty).' bunch of carrots @ $1.50 each <br />';
        echo htmlspecialchars($bellpepperqty).' bellpeppers @ $2.00 each <br />';
        echo htmlspecialchars($tomatoqty).' tomatoes @ $1.50 each <br />';
        
        $totalqty = 0;
        $totalqty = $carrotqty + $bellpepperqty + $tomatoqty;
        echo "<p>Items ordered: ".$totalqty."<br />";
        $totalamount = 0.00;
            
        define('CARROTPRICE', 1.50);
        define('BELLPEPPERPRICE', 2.00);
        define('TOMATOPRICE', 1.50);
        
        $totalamount = $carrotqty* CARROTPRICE
                      + $bellpepperqty * BELLPEPPERPRICE
                      + $tomatoqty + TOMATOPRICE;
          
        echo "Subtotal: $".number_format($totalamount, 2)."<br />";
        
        $taxrate = 0.10; // local sales tax is 10%
        $totalamount = $totalamount * (1 +$taxrate);
        echo  "Thank you for your purchase! Your total including tax: $".number_format($totalamount, 2)."</p>"
    ?>
       </section>
        </main>
    </body>
</html>